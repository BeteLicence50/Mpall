<b> Installation </b>

* Installer nodejs, de préférence LTS
https://nodejs.org/fr/

Après ça lancé le fichier **install.bat** puis les modules vont s'installé
une fois ceci fait vous pouvez lancé le fichier **config.json** et 
mettre le token du bot, prefix, votre id et le message à envoyée
et ensuite pour terminée lancé le fichier **start.bat** et
vous aurez les lien des serveur ou es votre bot vous 
rejoingez un serveur au hasard et vous faite la commande
"prefix"mp et ensuite ça va envoyé le texte que
vous aurez défini dans le **config.json**

<h2> Crédits <h2/>
<h4> Base du fichier: https://github.com/Nomade7 <h4/>
<h4> Re construction du fichier + amélioration: https://github.com/KASav1 <h4/>
